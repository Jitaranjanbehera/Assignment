package com.example.jitranjan.service;

import com.example.jitranjan.entity.Marks;
import com.example.jitranjan.entity.Student;
import com.example.jitranjan.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Transactional
    public void saveStudent(Student student) {
        studentRepository.save(student);
    }

    public Map<String, Float> getAverage() {

        List<Student> allStudents = studentRepository.findAll();
        int noOfStudents = allStudents.size();
        int toatalMarks = 0;

        Map<String, Float> details = new HashMap<>();
;
        for(Student student : allStudents) {
            List<Marks> marks = student.getMarks();

            Marks sem1Mark = marks.get(0);
            Marks sem2Marks = marks.get(1);

            int totalSem1Marks = sem1Mark.getEnglish() + sem1Mark.getScience() + sem1Mark.getMath();
            int totalSem2Marks = sem2Marks.getEnglish() + sem2Marks.getScience() + sem2Marks.getMath();
            toatalMarks = toatalMarks + totalSem1Marks + totalSem2Marks;

        }
        float avg =  toatalMarks / noOfStudents;

        details.put("average", avg);
        return details;
    }
}
