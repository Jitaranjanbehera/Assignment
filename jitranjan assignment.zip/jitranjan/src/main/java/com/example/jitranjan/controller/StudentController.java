package com.example.jitranjan.controller;

import com.example.jitranjan.entity.Student;
import com.example.jitranjan.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
public class StudentController {

    @Autowired
    private StudentService studentService;

    @PostMapping("students")
    public void saveStudent(@RequestBody Student student) {
       /* Marks mark1 = new Marks();
        mark1.setMath(50);
        mark1.setEnglish(45);
        mark1.setScience(67);
        mark1.setSem("SEM1");

        Marks mark2 = new Marks();
        mark2.setMath(50);
        mark2.setEnglish(45);
        mark2.setScience(67);
        mark2.setSem("SEM1");

        List<Marks> lists = new ArrayList<>();
        lists.add(mark1);
        lists.add(mark2);
        Student student = new Student();
        student.setName("Student1");
        student.setMarks(lists); */

        studentService.saveStudent(student);



    }

    @GetMapping("/students/average")
    public Map<String, Float> getAverage() {
       return studentService.getAverage();
    }
}
